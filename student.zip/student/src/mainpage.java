
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class mainpage extends JFrame implements ActionListener{
 
    
    JTable t1;
    JButton add,update,delete,cancel;

    String x[] = {"Roll No","Name","Last Name","Date of Birth","Address","Phone","Gender"};
    String y[][] = new String[20][7];
    int i=0, j=0;
    mainpage(){
        
        
      
        
        add = new JButton("Add Student");
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add.setBounds(200, 450, 200 ,30);
        add(add);
            
        
        
        update = new JButton("Update Student");
        update.setBackground(Color.BLACK);
        update.setForeground(Color.WHITE);
        update.setBounds(450, 450, 200 ,30);
        add(update);
        
       
        
        delete = new JButton("Delete Student");
        delete.setBackground(Color.BLACK);
        delete.setForeground(Color.WHITE);
        delete.setBounds(700, 450, 200 ,30);
        add(delete);

        cancel = new JButton("Cancel");
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.setBounds(950, 450, 200 ,30);
        add(cancel);
        
        add.addActionListener(this);
        update.addActionListener(this);
        delete.addActionListener(this);
        cancel.addActionListener(this);
        
        
        try{
            conn c1  = new conn();
            String s1 = "select * from details";
            ResultSet rs  = c1.s.executeQuery(s1);
            while(rs.next()){
              
                y[i][j++]=rs.getString("rollno");
                y[i][j++]=rs.getString("name");
                y[i][j++]=rs.getString("lastname");
                y[i][j++]=rs.getString("dob");
                y[i][j++]=rs.getString("address");
                y[i][j++]=rs.getString("phone");
                y[i][j++]=rs.getString("gender");
                i++;
                j=0;
            }
            t1 = new JTable(y,x);
            JScrollPane sp = new JScrollPane(t1);
            sp.setBounds(20,20,1200,330);
            add(sp);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
       
        
        // getContentPane().setcancelground(Color.WHITE);
        
        add.addActionListener(this);

        setSize(1260,650);
        setLocation(200,200);
        setLayout(null);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent ae){

        String msg = ae.getActionCommand();
        if(msg.equals("Add Student"))
        {
            new addstudent().setVisible(true);
            setVisible(false);
            
        }
        else if(msg.equals("Update Student"))
        {
            
            new update().setVisible(true);
        }
        else if(msg.equals("Delete Student"))
        {
            new delete().setVisible(true);
      
        }
        else if(msg.equals("Cancel"))
        {
        
            System.exit(0);
      
        }
    }
    public static void main(String[] args){
        new mainpage();
    }
    
}
